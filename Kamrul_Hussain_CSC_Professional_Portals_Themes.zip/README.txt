KAMRUL HUSSAIN CSC CENTRE — PROFESSIONAL PORTALS

Files:
- index.html: Customer document request portal
- admin.html: Admin dashboard preview
- README.txt: notes and limitations

Theme button added to the top corner of both portals:
- Blue RGB
- Red RGB
- Green RGB
- Night mode (dark theme)

This remains a front-end prototype. Actual server uploads, live admin queue, authentication, QR URL and printer integration still need backend setup. Admin rows are sample data.
